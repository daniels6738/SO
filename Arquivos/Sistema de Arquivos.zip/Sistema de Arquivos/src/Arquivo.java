import java.time.LocalDateTime;

public class Arquivo{
    private String nome;
    private LocalDateTime dataCriacao;
    private Bloco cabeca;

    public Arquivo(String nome, int tamanho, Bloco[] memoria){
        this.nome = nome;
        this.dataCriacao = LocalDateTime.now();
        this.cabeca = alocaBlocos(memoria, tamanho);
        int index = -1; //-1 para debug, valor impossivel em array
        for(int i = 0; i < memoria.length;i++){
            if (cabeca == memoria[i]){
                index = i;
            }
        }

        System.out.println("Bloco da cabeça da lista encadeada: " + index);
    }

    public Bloco getCabeca() {
        return this.cabeca;
    }

    public void setCabeca(Bloco cabeca) {
        this.cabeca = cabeca;
    }    

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDateTime getDataCriacao() {
        return this.dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public Bloco achaBlocoLivre(Bloco[] mem){
        for(Bloco b:mem){
            if(b.getOcupado() == false){
                return b; //Definir cabeça da lista do arquivo
            }
        }
        return null;
    }

    public Bloco alocaBlocos(Bloco[] mem, int tamanho){
        Bloco cabeca;
        int rest = tamanho;
        cabeca = achaBlocoLivre(mem);
        Bloco atual = cabeca;
        while(rest > 0){
            rest--;
            atual.setOcupado(true);
            if(rest != 0){
                atual.setNext(achaBlocoLivre(mem));
                atual = atual.getNext();
            }
            else{
                atual.setUltimo(true);
            }
        }
        return cabeca;
    }
    
    public int calcTamanho(){
        Bloco atual = this.cabeca;
        int tamanho = 0;
        while(atual.isUltimo() == false){
            tamanho++;
            atual = atual.getNext();
        }
        tamanho++; //para contar o tamanho do ultimo bloco :)
        return tamanho;
    }

    public void liberarMem(){
        Bloco atual = getCabeca();
        while(atual.isUltimo() == false){
            atual.setOcupado(false);
            atual = atual.getNext();
        }
        atual.setOcupado(false);
        atual.setUltimo(false);
    }

    @Override
    public String toString() {
        return "\nNome do arquivo: " + getNome() + "\nTamanho:" + calcTamanho() + "KB\nData de criação: " + getDataCriacao();
    }

}